
from main import *
import importlib
import sys
sys.path.append("/var/task/")

#import os
#if os.environ.get('AWS_LAMBDA_FUNCTION_VERSION') is None or os.environ.get('VPC_ENABLED') != 'TRUE':
#    print('setting rds in event')
#    db = None
#else:
#    db = prds()

def lambda_handler(event, context):
    method = event['requestContext']['httpMethod']
    resource = event['requestContext']['resourcePath']
    #print(json.dumps(event, default=str))
    data = [{'method': 'DELETE', 'path': 'deleteFund', 'filePath': 'deleteFund/delete.py', 'pathParameters': [], 'urlRule': '/deleteFund', 'rootPath': 'deleteFund'}]
    for ep in data:
        if method.lower() == ep.get('method').lower() and resource == ep.get('urlRule'):
            module_loc = ep.get('filePath')
            module_loc = module_loc.replace('.py', '')
            module_loc = module_loc.replace('/', '.')
            globals()['module'] = importlib.import_module(module_loc)
            #if os.environ.get('DB_ENDPOINT', '').startswith('proxy-') and 'db' in globals():
            #    event['db_object'] = db

            return globals()['module'].lambda_handler(event, context)
